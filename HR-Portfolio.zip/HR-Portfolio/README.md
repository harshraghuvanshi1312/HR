
  # HR Portfolio

  This is a code bundle for HR Portfolio. The original project is available at https://www.figma.com/design/xu1XCV3p8LemdaVDjhQXxG/HR-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  